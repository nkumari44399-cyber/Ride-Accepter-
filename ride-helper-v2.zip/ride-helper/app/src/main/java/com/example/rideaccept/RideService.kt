package com.example.rideaccept

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class RideService : AccessibilityService() {
  // Exact match only (lowercase), so "Accept terms" etc. won't be tapped
  private val labels = setOf("accept", "accept ride", "accept booking")
  private var last = 0L

  override fun onAccessibilityEvent(e: AccessibilityEvent?) {
    val prefs = getSharedPreferences("p", MODE_PRIVATE)
    if (!prefs.getBoolean("on", false)) return
    val now = System.currentTimeMillis()
    if (now - last < 800) return
    val root = rootInActiveWindow ?: return
    val target = find(root, 0) ?: return
    var c: AccessibilityNodeInfo? = target
    while (c != null && !c.isClickable) c = c.parent
    if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
      last = now
    }
  }

  private fun find(n: AccessibilityNodeInfo, depth: Int): AccessibilityNodeInfo? {
    if (depth > 30) return null
    val t = n.text?.toString()?.trim()?.lowercase()
    val d = n.contentDescription?.toString()?.trim()?.lowercase()
    if ((t != null && t in labels) || (d != null && d in labels)) return n
    for (i in 0 until n.childCount) {
      val ch = n.getChild(i) ?: continue
      val r = find(ch, depth + 1)
      if (r != null) return r
    }
    return null
  }

  override fun onInterrupt() {}
}
