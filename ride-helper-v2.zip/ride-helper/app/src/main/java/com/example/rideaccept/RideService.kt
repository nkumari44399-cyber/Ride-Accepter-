package com.example.rideaccept

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

class RideService : AccessibilityService() {

  private val labels = setOf("accept", "accept ride", "accept booking")
  private val fareRx = Regex("""(?:₹|\b(?:rs\.?|inr))\s*([0-9][0-9,]*(?:\.[0-9]+)?)""", RegexOption.IGNORE_CASE)
  private val kmRx = Regex("""([0-9]+(?:\.[0-9]+)?)\s*(km|m)\b""", RegexOption.IGNORE_CASE)

  private lateinit var prefs: SharedPreferences
  private var last = 0L
  private var lastSig = ""
  private var lastInfo = ""

  private var wm: WindowManager? = null
  private var bubble: View? = null
  private var dot: View? = null
  private var label: TextView? = null
  private var lp: WindowManager.LayoutParams? = null

  private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> refreshOverlay() }

  override fun onServiceConnected() {
    super.onServiceConnected()
    prefs = getSharedPreferences("p", MODE_PRIVATE)
    prefs.registerOnSharedPreferenceChangeListener(listener)
    wm = getSystemService(WINDOW_SERVICE) as WindowManager
    refreshOverlay()
  }

  override fun onUnbind(intent: Intent?): Boolean {
    if (::prefs.isInitialized) prefs.unregisterOnSharedPreferenceChangeListener(listener)
    removeOverlay()
    return super.onUnbind(intent)
  }

  override fun onAccessibilityEvent(e: AccessibilityEvent?) {
    if (!::prefs.isInitialized || !prefs.getBoolean("on", false)) return
    val now = System.currentTimeMillis()
    if (now - last < 800) return
    val root = rootInActiveWindow ?: return
    val btn = findButton(root, 0) ?: return

    val texts = ArrayList<String>()
    collect(root, texts, 0)
    val all = texts.joinToString(" | ")

    val fare = fareRx.find(all)?.groupValues?.get(1)?.replace(",", "")?.toFloatOrNull()
    val kms = kmRx.findAll(all).map {
      val v = it.groupValues[1].toFloat()
      if (it.groupValues[2].equals("m", true)) v / 1000f else v
    }.toList()
    val km = if (kms.isEmpty()) null else if (prefs.getInt("kmMode", 0) == 0) kms.first() else kms.last()

    val info = "₹${f(fare)} · ${f(km)} km"
    val why = reject(fare, km)

    if (why == null) {
      var c: AccessibilityNodeInfo? = btn
      while (c != null && !c.isClickable) c = c.parent
      if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
        last = now
        lastSig = ""
        lastInfo = "✓ $info"
        bump("acc")
      }
    } else {
      val sig = "$fare|$km"
      if (sig != lastSig) {
        lastSig = sig
        lastInfo = "✗ $why  $info"
        bump("skip")
      }
    }
  }

  private fun reject(fare: Float?, km: Float?): String? {
    val minF = prefs.getFloat("minFare", -1f)
    val maxF = prefs.getFloat("maxFare", -1f)
    val minK = prefs.getFloat("minKm", -1f)
    val maxK = prefs.getFloat("maxKm", -1f)
    if (minF >= 0 || maxF >= 0) {
      if (fare == null) return "fare?"
      if (minF >= 0 && fare < minF) return "fare kam"
      if (maxF >= 0 && fare > maxF) return "fare zyada"
    }
    if (minK >= 0 || maxK >= 0) {
      if (km == null) return "km?"
      if (minK >= 0 && km < minK) return "km kam"
      if (maxK >= 0 && km > maxK) return "km zyada"
    }
    return null
  }

  private fun f(v: Float?): String =
    if (v == null) "?" else if (v == v.toInt().toFloat()) v.toInt().toString() else String.format("%.1f", v)

  private fun bump(key: String) {
    prefs.edit().putInt(key, prefs.getInt(key, 0) + 1).apply()
  }

  private fun findButton(n: AccessibilityNodeInfo, depth: Int): AccessibilityNodeInfo? {
    if (depth > 40) return null
    val t = n.text?.toString()?.trim()?.lowercase()
    val d = n.contentDescription?.toString()?.trim()?.lowercase()
    if ((t != null && t in labels) || (d != null && d in labels)) return n
    for (i in 0 until n.childCount) {
      val ch = n.getChild(i) ?: continue
      val r = findButton(ch, depth + 1)
      if (r != null) return r
    }
    return null
  }

  private fun collect(n: AccessibilityNodeInfo, out: MutableList<String>, depth: Int) {
    if (depth > 40) return
    n.text?.toString()?.let { if (it.isNotBlank()) out.add(it.trim()) }
    n.contentDescription?.toString()?.let { if (it.isNotBlank()) out.add(it.trim()) }
    for (i in 0 until n.childCount) n.getChild(i)?.let { collect(it, out, depth + 1) }
  }

  // ---------- Floating bubble ----------

  private fun refreshOverlay() {
    if (!::prefs.isInitialized) return
    if (!prefs.getBoolean("overlay", true)) {
      removeOverlay()
      return
    }
    if (bubble == null) createOverlay()
    val on = prefs.getBoolean("on", false)
    (dot?.background as? GradientDrawable)?.setColor(Color.parseColor(if (on) "#22C55E" else "#EF4444"))
    label?.text = (if (on) "ON" else "OFF") + (if (lastInfo.isNotEmpty()) "  •  $lastInfo" else "")
  }

  private fun createOverlay() {
    val d = resources.displayMetrics.density
    val dotView = View(this).apply {
      background = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(Color.RED)
      }
      layoutParams = LinearLayout.LayoutParams((10 * d).toInt(), (10 * d).toInt()).apply {
        rightMargin = (8 * d).toInt()
      }
    }
    val text = TextView(this).apply {
      setTextColor(Color.WHITE)
      textSize = 13f
      typeface = Typeface.DEFAULT_BOLD
    }
    val box = LinearLayout(this).apply {
      orientation = LinearLayout.HORIZONTAL
      gravity = Gravity.CENTER_VERTICAL
      setPadding((14 * d).toInt(), (9 * d).toInt(), (16 * d).toInt(), (9 * d).toInt())
      background = GradientDrawable().apply {
        setColor(Color.parseColor("#E6181B22"))
        cornerRadius = 40 * d
        setStroke((1 * d).toInt(), Color.parseColor("#33FFFFFF"))
      }
      addView(dotView)
      addView(text)
    }
    val params = WindowManager.LayoutParams(
      WindowManager.LayoutParams.WRAP_CONTENT,
      WindowManager.LayoutParams.WRAP_CONTENT,
      WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
      WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
      PixelFormat.TRANSLUCENT
    ).apply {
      gravity = Gravity.TOP or Gravity.START
      x = prefs.getInt("ox", 24)
      y = prefs.getInt("oy", 300)
    }

    var sx = 0
    var sy = 0
    var tx = 0f
    var ty = 0f
    var moved = false
    box.setOnTouchListener { _, ev ->
      when (ev.actionMasked) {
        MotionEvent.ACTION_DOWN -> {
          sx = params.x; sy = params.y
          tx = ev.rawX; ty = ev.rawY
          moved = false
        }
        MotionEvent.ACTION_MOVE -> {
          val dx = ev.rawX - tx
          val dy = ev.rawY - ty
          if (abs(dx) > 10 || abs(dy) > 10) moved = true
          if (moved) {
            params.x = sx + dx.toInt()
            params.y = sy + dy.toInt()
            try { wm?.updateViewLayout(box, params) } catch (_: Exception) {}
          }
        }
        MotionEvent.ACTION_UP -> {
          if (moved) {
            prefs.edit().putInt("ox", params.x).putInt("oy", params.y).apply()
          } else {
            prefs.edit().putBoolean("on", !prefs.getBoolean("on", false)).apply()
          }
        }
      }
      true
    }

    try {
      wm?.addView(box, params)
      bubble = box
      dot = dotView
      label = text
      lp = params
    } catch (_: Exception) {
    }
  }

  private fun removeOverlay() {
    try { bubble?.let { wm?.removeView(it) } } catch (_: Exception) {}
    bubble = null
    dot = null
    label = null
    lp = null
  }

  override fun onInterrupt() {}
}
