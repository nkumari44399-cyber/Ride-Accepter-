package com.example.rideaccept

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

data class Entry(val t: Long, val s: String, val fare: Float?, val km: Float?, val why: String)

object History {
  private const val KEY = "list"
  private const val MAX = 300

  private fun sp(c: Context) = c.getSharedPreferences("h", Context.MODE_PRIVATE)

  fun all(c: Context): List<Entry> {
    val out = ArrayList<Entry>()
    try {
      val arr = JSONArray(sp(c).getString(KEY, "[]"))
      for (i in 0 until arr.length()) {
        val o = arr.getJSONObject(i)
        val f = o.optDouble("f", Double.NaN)
        val k = o.optDouble("k", Double.NaN)
        out.add(
          Entry(
            o.getLong("t"), o.getString("s"),
            if (f.isNaN()) null else f.toFloat(),
            if (k.isNaN()) null else k.toFloat(),
            o.optString("w", "")
          )
        )
      }
    } catch (_: Exception) {
    }
    return out
  }

  private fun toJson(e: Entry): JSONObject {
    val o = JSONObject()
    o.put("t", e.t)
    o.put("s", e.s)
    val f = e.fare
    val k = e.km
    if (f != null) o.put("f", f.toDouble())
    if (k != null) o.put("k", k.toDouble())
    o.put("w", e.why)
    return o
  }

  @Synchronized
  fun add(c: Context, s: String, fare: Float?, km: Float?, why: String = "") {
    val list = all(c)
    val keep = if (list.size >= MAX) list.subList(list.size - MAX + 1, list.size) else list
    val arr = JSONArray()
    for (e in keep) arr.put(toJson(e))
    arr.put(toJson(Entry(System.currentTimeMillis(), s, fare, km, why)))
    sp(c).edit().putString(KEY, arr.toString()).apply()
  }

  fun clear(c: Context) {
    sp(c).edit().remove(KEY).apply()
  }

  private fun startOfToday(): Long {
    val c = Calendar.getInstance()
    c.set(Calendar.HOUR_OF_DAY, 0)
    c.set(Calendar.MINUTE, 0)
    c.set(Calendar.SECOND, 0)
    c.set(Calendar.MILLISECOND, 0)
    return c.timeInMillis
  }

  fun today(c: Context): List<Entry> {
    val s = startOfToday()
    return all(c).filter { it.t >= s }
  }
}
