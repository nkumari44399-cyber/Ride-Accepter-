package com.example.rideaccept

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryActivity : BaseActivity() {

  private var filter = "all"
  private lateinit var list: LinearLayout
  private lateinit var summary: TextView
  private val chips = ArrayList<Pair<String, TextView>>()
  private val timeFmt = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())

  private fun tagOf(s: String) = when (s) {
    "acc" -> "ACCEPTED"
    "dry" -> "PRACTICE"
    else -> "SKIPPED"
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)

    val col = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL
      setPadding(dp(16), dp(24), dp(16), dp(32))
    }

    col.addView(button("← Wapas", cBg, cText) { finish() }.apply {
      layoutParams = LinearLayout.LayoutParams(WRAP, WRAP).apply { bottomMargin = dp(12) }
    })
    col.addView(tv("History", 28f, cText, true))
    summary = tv("", 13f, cMuted).apply { setPadding(0, dp(2), 0, dp(14)) }
    col.addView(summary)

    val chipRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    for ((key, name) in listOf("all" to "Sab", "acc" to "Accepted", "skip" to "Skipped", "dry" to "Practice")) {
      val c = tv(name, 13f, cText, true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(14), dp(8), dp(14), dp(8))
        setOnClickListener {
          filter = key
          paintChips()
          render()
        }
      }
      chips.add(key to c)
      chipRow.addView(c, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(8) })
    }
    col.addView(chipRow, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(14) })

    list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    col.addView(list)

    col.addView(rowOf(
      button("Share", cCard, cText) { share() },
      button("Clear", cCard, cRed) { confirmClear() }
    ).apply { setPadding(0, dp(12), 0, 0) })

    setContentView(ScrollView(this).apply {
      setBackgroundColor(cBg)
      addView(col)
    })
    paintChips()
  }

  override fun onResume() {
    super.onResume()
    render()
  }

  private fun paintChips() {
    for ((key, c) in chips) {
      val on = key == filter
      c.background = rounded(if (on) cGreen else cCard, 20, cStroke)
      c.setTextColor(if (on) Color.BLACK else cText)
    }
  }

  private fun render() {
    list.removeAllViews()
    val all = History.all(this).reversed()
    val shown = if (filter == "all") all else all.filter { it.s == filter }

    val today = History.today(this)
    val acc = today.filter { it.s == "acc" }
    var sum = 0f
    for (e in acc) sum += e.fare ?: 0f
    summary.text = "Aaj: ${acc.size} accepted · ₹${fmt(sum)} · ${today.count { it.s == "skip" }} skipped"

    if (shown.isEmpty()) {
      list.addView(tv("Abhi koi entry nahi hai.", 14f, cMuted).apply { setPadding(0, dp(24), 0, dp(24)) })
      return
    }
    for (e in shown) list.addView(row(e))
  }

  private fun row(e: Entry): View {
    val color = when (e.s) {
      "acc" -> cGreen
      "dry" -> cAmber
      else -> cRed
    }
    val dot = View(this).apply {
      background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
    }
    val fareTxt = e.fare?.let { fmt(it) } ?: "?"
    val kmTxt = e.km?.let { fmt(it) } ?: "?"
    val sub = timeFmt.format(Date(e.t)) + if (e.s == "skip" && e.why.isNotEmpty()) " · ${e.why}" else ""

    val mid = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL
      addView(tv("₹$fareTxt · $kmTxt km", 16f, cText, true))
      addView(tv(sub, 12f, cMuted))
    }
    return LinearLayout(this).apply {
      gravity = Gravity.CENTER_VERTICAL
      setPadding(dp(14), dp(12), dp(14), dp(12))
      background = rounded(cCard, 12, cStroke)
      layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8) }
      addView(dot, LinearLayout.LayoutParams(dp(10), dp(10)).apply { rightMargin = dp(12) })
      addView(mid, LinearLayout.LayoutParams(0, WRAP, 1f))
      addView(tv(tagOf(e.s), 11f, color, true))
    }
  }

  private fun share() {
    val sb = StringBuilder("Ride Helper history\n")
    for (e in History.all(this).reversed()) {
      sb.append(timeFmt.format(Date(e.t))).append(" | ").append(tagOf(e.s))
        .append(" | ₹").append(e.fare?.let { fmt(it) } ?: "?")
        .append(" | ").append(e.km?.let { fmt(it) } ?: "?").append(" km")
      if (e.why.isNotEmpty()) sb.append(" | ").append(e.why)
      sb.append("\n")
    }
    val i = Intent(Intent.ACTION_SEND).apply {
      type = "text/plain"
      putExtra(Intent.EXTRA_TEXT, sb.toString())
    }
    startActivity(Intent.createChooser(i, "History share karo"))
  }

  private fun confirmClear() {
    AlertDialog.Builder(this)
      .setMessage("Poori history delete karein?")
      .setPositiveButton("Haan") { _, _ ->
        History.clear(this)
        render()
      }
      .setNegativeButton("Nahi", null)
      .show()
  }
}
