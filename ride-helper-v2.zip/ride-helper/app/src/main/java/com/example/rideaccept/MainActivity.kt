package com.example.rideaccept

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

  private lateinit var prefs: SharedPreferences
  private lateinit var accDot: View
  private lateinit var accLabel: TextView
  private lateinit var mainSw: Switch
  private lateinit var ovSw: Switch
  private lateinit var statAcc: TextView
  private lateinit var statSkip: TextView

  private val cBg = Color.parseColor("#0F1115")
  private val cCard = Color.parseColor("#181B22")
  private val cStroke = Color.parseColor("#262A33")
  private val cText = Color.WHITE
  private val cMuted = Color.parseColor("#8B93A1")
  private val cGreen = Color.parseColor("#22C55E")
  private val cRed = Color.parseColor("#EF4444")
  private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
  private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

  private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

  private fun rounded(color: Int, r: Int, stroke: Int? = null) = GradientDrawable().apply {
    setColor(color)
    cornerRadius = dp(r).toFloat()
    if (stroke != null) setStroke(dp(1), stroke)
  }

  private fun tv(t: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
    text = t
    textSize = sp
    setTextColor(color)
    if (bold) typeface = Typeface.DEFAULT_BOLD
  }

  private fun fmt(v: Float): String = if (v == v.toLong().toFloat()) v.toLong().toString() else v.toString()

  private fun card(parent: LinearLayout, title: String?): LinearLayout {
    val c = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL
      setPadding(dp(16), dp(14), dp(16), dp(16))
      background = rounded(cCard, 16, cStroke)
    }
    c.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(12) }
    if (title != null) {
      c.addView(tv(title.uppercase(), 11f, cMuted, true).apply {
        letterSpacing = 0.08f
        setPadding(0, 0, 0, dp(10))
      })
    }
    parent.addView(c)
    return c
  }

  private fun button(t: String, bg: Int, fg: Int, onClick: () -> Unit) = TextView(this).apply {
    text = t
    textSize = 14f
    setTextColor(fg)
    typeface = Typeface.DEFAULT_BOLD
    gravity = Gravity.CENTER
    setPadding(dp(16), dp(12), dp(16), dp(12))
    background = rounded(bg, 12)
    setOnClickListener { onClick() }
  }

  private fun field(label: String, key: String, hintText: String): LinearLayout {
    val w = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    w.addView(tv(label, 12f, cMuted).apply { setPadding(0, 0, 0, dp(6)) })
    val et = EditText(this).apply {
      setTextColor(cText)
      setHintTextColor(cMuted)
      hint = hintText
      textSize = 16f
      inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
      isSingleLine = true
      setPadding(dp(12), dp(12), dp(12), dp(12))
      background = rounded(cBg, 10, cStroke)
      val v = prefs.getFloat(key, -1f)
      if (v >= 0) setText(fmt(v))
      addTextChangedListener(object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun afterTextChanged(s: Editable?) {
          val x = s?.toString()?.toFloatOrNull()
          val ed = prefs.edit()
          if (x == null) ed.remove(key) else ed.putFloat(key, x)
          ed.apply()
        }
      })
    }
    w.addView(et)
    return w
  }

  private fun pair(a: View, b: View) = LinearLayout(this).apply {
    orientation = LinearLayout.HORIZONTAL
    addView(a, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(6) })
    addView(b, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(6) })
  }

  private fun switchRow(parent: LinearLayout, title: String, sub: String, key: String, def: Boolean): Switch {
    val sw = Switch(this).apply {
      isChecked = prefs.getBoolean(key, def)
      setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean(key, v).apply() }
    }
    val left = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL
      addView(tv(title, 16f, cText, true))
      addView(tv(sub, 12f, cMuted))
    }
    val r = LinearLayout(this).apply {
      gravity = Gravity.CENTER_VERTICAL
      setPadding(0, dp(6), 0, dp(6))
      addView(left, LinearLayout.LayoutParams(0, WRAP, 1f))
      addView(sw)
    }
    parent.addView(r)
    return sw
  }

  private fun segmented(): LinearLayout {
    val row = LinearLayout(this).apply {
      background = rounded(cBg, 12, cStroke)
      setPadding(dp(3), dp(3), dp(3), dp(3))
    }
    val a = tv("Pickup km (pehla)", 13f, cText, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(10)) }
    val b = tv("Trip km (aakhri)", 13f, cText, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(10)) }
    fun paint() {
      val m = prefs.getInt("kmMode", 0)
      a.background = rounded(if (m == 0) cGreen else Color.TRANSPARENT, 10)
      b.background = rounded(if (m == 1) cGreen else Color.TRANSPARENT, 10)
      a.setTextColor(if (m == 0) Color.BLACK else cText)
      b.setTextColor(if (m == 1) Color.BLACK else cText)
    }
    a.setOnClickListener { prefs.edit().putInt("kmMode", 0).apply(); paint() }
    b.setOnClickListener { prefs.edit().putInt("kmMode", 1).apply(); paint() }
    row.addView(a, LinearLayout.LayoutParams(0, WRAP, 1f))
    row.addView(b, LinearLayout.LayoutParams(0, WRAP, 1f))
    paint()
    return row
  }

  private fun accEnabled(): Boolean {
    val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
    return s.contains("$packageName/")
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    prefs = getSharedPreferences("p", MODE_PRIVATE)

    val col = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL
      setPadding(dp(16), dp(28), dp(16), dp(32))
    }
    col.addView(tv("Ride Helper", 28f, cText, true))
    col.addView(tv("Fare aur distance filter ke saath auto-accept", 13f, cMuted).apply {
      setPadding(0, dp(2), 0, dp(18))
    })

    // Status
    val st = card(col, "Setup")
    accDot = View(this).apply {
      background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(cRed) }
    }
    accLabel = tv("", 15f, cText, true)
    val stRow = LinearLayout(this).apply {
      gravity = Gravity.CENTER_VERTICAL
      addView(accDot, LinearLayout.LayoutParams(dp(10), dp(10)).apply { rightMargin = dp(10) })
      addView(accLabel)
    }
    st.addView(stRow)
    st.addView(button("Accessibility settings kholo", cGreen, Color.BLACK) {
      startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }.apply {
      layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) }
    })
    st.addView(tv("Android 13+: App info → ⋮ → Allow restricted settings", 11f, cMuted).apply {
      setPadding(0, dp(8), 0, 0)
    })

    // Controls
    val ct = card(col, "Control")
    mainSw = switchRow(ct, "Auto-accept", "Filter match hone par Accept dabaye", "on", false)
    ovSw = switchRow(ct, "Floating bubble", "Screen par ON/OFF, drag karke hilao", "overlay", true)

    // Filters
    val fl = card(col, "Filters (khaali = no limit)")
    fl.addView(tv("Fare (₹)", 14f, cText, true).apply { setPadding(0, 0, 0, dp(8)) })
    fl.addView(pair(field("Minimum", "minFare", "e.g. 60"), field("Maximum", "maxFare", "e.g. 500")))
    fl.addView(tv("Distance (km)", 14f, cText, true).apply { setPadding(0, dp(16), 0, dp(8)) })
    fl.addView(pair(field("Minimum", "minKm", "e.g. 1"), field("Maximum", "maxKm", "e.g. 15")))
    fl.addView(tv("Kaunsa km check karna hai", 12f, cMuted).apply { setPadding(0, dp(16), 0, dp(6)) })
    fl.addView(segmented())
    fl.addView(tv("Auto-save hota hai. Filter set ho aur app se value na mile to ride skip hoti hai.", 11f, cMuted).apply {
      setPadding(0, dp(10), 0, 0)
    })

    // Stats
    val sc = card(col, "Aaj tak")
    statAcc = tv("0", 28f, cGreen, true)
    statSkip = tv("0", 28f, cRed, true)
    val a = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL
      addView(statAcc)
      addView(tv("Accepted", 12f, cMuted))
    }
    val s = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL
      addView(statSkip)
      addView(tv("Skipped", 12f, cMuted))
    }
    sc.addView(pair(a, s))
    sc.addView(button("Reset", cBg, cText) {
      prefs.edit().putInt("acc", 0).putInt("skip", 0).apply()
      refresh()
    }.apply {
      layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) }
    })

    col.addView(tv(
      "Tip: pehli ride par bubble dekho. Wahan ✓/✗ ke saath fare aur km dikhega, usse verify karo ki sahi padh raha hai. " +
        "Kai platforms automation allow nahi karte, apni zimmedari par use karo.",
      11f, cMuted
    ))

    setContentView(ScrollView(this).apply {
      setBackgroundColor(cBg)
      isFillViewport = true
      addView(col)
    })
  }

  private fun refresh() {
    val en = accEnabled()
    (accDot.background as GradientDrawable).setColor(if (en) cGreen else cRed)
    accLabel.text = if (en) "Accessibility service chalu hai" else "Accessibility service band hai"
    mainSw.isChecked = prefs.getBoolean("on", false)
    ovSw.isChecked = prefs.getBoolean("overlay", true)
    statAcc.text = prefs.getInt("acc", 0).toString()
    statSkip.text = prefs.getInt("skip", 0).toString()
  }

  override fun onResume() {
    super.onResume()
    refresh()
  }
}
