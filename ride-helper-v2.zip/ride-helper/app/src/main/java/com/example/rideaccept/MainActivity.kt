package com.example.rideaccept

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class MainActivity : BaseActivity() {

  private lateinit var accDot: View
  private lateinit var accLabel: TextView
  private lateinit var mainSw: Switch
  private lateinit var ovSw: Switch
  private lateinit var dryTag: TextView
  private lateinit var statAcc: TextView
  private lateinit var statEarn: TextView
  private lateinit var statSkip: TextView

  private fun accEnabled(): Boolean {
    val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
    return s.contains("$packageName/")
  }

  private fun stat(valueView: TextView, label: String) = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    addView(valueView)
    addView(tv(label, 12f, cMuted))
  }

  private fun segmented(): LinearLayout {
    val row = LinearLayout(this).apply {
      background = rounded(cBg, 12, cStroke)
      setPadding(dp(3), dp(3), dp(3), dp(3))
    }
    val a = tv("Pickup km (pehla)", 13f, cText, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(10)) }
    val b = tv("Trip km (aakhri)", 13f, cText, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(10)) }
    fun paint() {
      val m = prefs.getInt("kmMode", 0)
      a.background = rounded(if (m == 0) cGreen else Color.TRANSPARENT, 10)
      b.background = rounded(if (m == 1) cGreen else Color.TRANSPARENT, 10)
      a.setTextColor(if (m == 0) Color.BLACK else cText)
      b.setTextColor(if (m == 1) Color.BLACK else cText)
    }
    a.setOnClickListener { prefs.edit().putInt("kmMode", 0).apply(); paint() }
    b.setOnClickListener { prefs.edit().putInt("kmMode", 1).apply(); paint() }
    row.addView(a, LinearLayout.LayoutParams(0, WRAP, 1f))
    row.addView(b, LinearLayout.LayoutParams(0, WRAP, 1f))
    paint()
    return row
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)

    val col = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL
      setPadding(dp(16), dp(28), dp(16), dp(32))
    }
    col.addView(tv("Ride Helper", 28f, cText, true))
    col.addView(tv("Filter, history aur practice mode ke saath auto-accept", 13f, cMuted).apply {
      setPadding(0, dp(2), 0, dp(18))
    })

    // Setup
    val st = card(col, "Setup")
    accDot = View(this).apply {
      background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(cRed) }
    }
    accLabel = tv("", 15f, cText, true)
    st.addView(LinearLayout(this).apply {
      gravity = Gravity.CENTER_VERTICAL
      addView(accDot, LinearLayout.LayoutParams(dp(10), dp(10)).apply { rightMargin = dp(10) })
      addView(accLabel)
    })
    st.addView(button("Accessibility settings kholo", cGreen, Color.BLACK) {
      startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }.apply {
      layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) }
    })
    st.addView(tv("Android 13+: App info → ⋮ → Allow restricted settings", 11f, cMuted).apply {
      setPadding(0, dp(8), 0, 0)
    })

    // Control
    val ct = card(col, "Control")
    mainSw = switchRow(ct, "Auto-accept", "Filter match hone par Accept dabaye", "on", false)
    switchRow(ct, "Practice mode", "Click nahi karta, sirf history mein likhta hai", "dry", false)
    ovSw = switchRow(ct, "Floating bubble", "Screen par ON/OFF, drag karke hilao", "overlay", true)
    switchRow(ct, "Accept alert", "Accept par vibrate + beep", "alert", true)

    // Filters
    val fl = card(col, "Filters (khaali = no limit)")
    fl.addView(tv("Fare (₹)", 14f, cText, true).apply { setPadding(0, 0, 0, dp(8)) })
    fl.addView(rowOf(field("Minimum", "minFare", "e.g. 60"), field("Maximum", "maxFare", "e.g. 500")))
    fl.addView(tv("Distance (km)", 14f, cText, true).apply { setPadding(0, dp(16), 0, dp(8)) })
    fl.addView(rowOf(field("Minimum", "minKm", "e.g. 1"), field("Maximum", "maxKm", "e.g. 15")))
    fl.addView(tv("Kaunsa km check karna hai", 12f, cMuted).apply { setPadding(0, dp(16), 0, dp(6)) })
    fl.addView(segmented())
    fl.addView(tv("Kamai aur limit", 14f, cText, true).apply { setPadding(0, dp(16), 0, dp(8)) })
    fl.addView(rowOf(field("Min ₹ per km (trip km se)", "minPk", "e.g. 8"), field("Aaj max rides", "maxRides", "e.g. 20")))
    fl.addView(tv("Auto-save hota hai. Filter set ho aur app se value na mile to ride skip hoti hai. Max rides poore hone par auto-accept khud OFF ho jata hai.", 11f, cMuted).apply {
      setPadding(0, dp(10), 0, 0)
    })

    // Today
    val sc = card(col, "Aaj")
    statAcc = tv("0", 26f, cGreen, true)
    statEarn = tv("₹0", 26f, cText, true)
    statSkip = tv("0", 26f, cRed, true)
    sc.addView(rowOf(stat(statAcc, "Accepted"), stat(statEarn, "Fare total"), stat(statSkip, "Skipped")))
    sc.addView(button("History dekho", cBg, cText) {
      startActivity(Intent(this, HistoryActivity::class.java))
    }.apply {
      layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14) }
    })

    dryTag = tv(
      "Tip: pehle Practice mode ON karke dekho ki fare/km sahi padh raha hai (History ya bubble mein). Phir Practice OFF karo. " +
        "Kai platforms automation allow nahi karte, apni zimmedari par use karo.",
      11f, cMuted
    )
    col.addView(dryTag)

    setContentView(ScrollView(this).apply {
      setBackgroundColor(cBg)
      isFillViewport = true
      addView(col)
    })
  }

  private fun refresh() {
    val en = accEnabled()
    (accDot.background as GradientDrawable).setColor(if (en) cGreen else cRed)
    accLabel.text = if (en) "Accessibility service chalu hai" else "Accessibility service band hai"
    mainSw.isChecked = prefs.getBoolean("on", false)
    ovSw.isChecked = prefs.getBoolean("overlay", true)
    val today = History.today(this)
    val acc = today.filter { it.s == "acc" }
    var sum = 0f
    for (e in acc) sum += e.fare ?: 0f
    statAcc.text = acc.size.toString()
    statEarn.text = "₹" + fmt(sum)
    statSkip.text = today.count { it.s == "skip" }.toString()
  }

  override fun onResume() {
    super.onResume()
    refresh()
  }
}
