package com.example.rideaccept

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
  override fun onCreate(b: Bundle?) {
    super.onCreate(b)
    val prefs = getSharedPreferences("p", MODE_PRIVATE)
    val box = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL
      setPadding(48, 96, 48, 48)
    }
    val btn = Button(this).apply {
      text = "1. Accessibility service ON karo"
      setOnClickListener {
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
      }
    }
    val sw = Switch(this).apply {
      text = "Auto-accept ON/OFF"
      isChecked = prefs.getBoolean("on", false)
      setOnCheckedChangeListener { _, v ->
        prefs.edit().putBoolean("on", v).apply()
      }
    }
    box.addView(btn)
    box.addView(sw)
    setContentView(box)
  }
}
