package com.example.rideaccept

import android.app.Activity
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

abstract class BaseActivity : Activity() {

  protected val prefs: SharedPreferences by lazy { getSharedPreferences("p", MODE_PRIVATE) }

  protected val cBg = Color.parseColor("#0F1115")
  protected val cCard = Color.parseColor("#181B22")
  protected val cStroke = Color.parseColor("#262A33")
  protected val cText = Color.WHITE
  protected val cMuted = Color.parseColor("#8B93A1")
  protected val cGreen = Color.parseColor("#22C55E")
  protected val cRed = Color.parseColor("#EF4444")
  protected val cAmber = Color.parseColor("#F59E0B")
  protected val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
  protected val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

  protected fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

  protected fun rounded(color: Int, r: Int, stroke: Int? = null) = GradientDrawable().apply {
    setColor(color)
    cornerRadius = dp(r).toFloat()
    if (stroke != null) setStroke(dp(1), stroke)
  }

  protected fun tv(t: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
    text = t
    textSize = sp
    setTextColor(color)
    if (bold) typeface = Typeface.DEFAULT_BOLD
  }

  protected fun fmt(v: Float): String = if (v == v.toLong().toFloat()) v.toLong().toString() else String.format("%.1f", v)

  protected fun card(parent: LinearLayout, title: String?): LinearLayout {
    val c = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL
      setPadding(dp(16), dp(14), dp(16), dp(16))
      background = rounded(cCard, 16, cStroke)
    }
    c.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(12) }
    if (title != null) {
      c.addView(tv(title.uppercase(), 11f, cMuted, true).apply {
        letterSpacing = 0.08f
        setPadding(0, 0, 0, dp(10))
      })
    }
    parent.addView(c)
    return c
  }

  protected fun button(t: String, bg: Int, fg: Int, onClick: () -> Unit) = TextView(this).apply {
    text = t
    textSize = 14f
    setTextColor(fg)
    typeface = Typeface.DEFAULT_BOLD
    gravity = Gravity.CENTER
    setPadding(dp(16), dp(12), dp(16), dp(12))
    background = rounded(bg, 12, cStroke)
    setOnClickListener { onClick() }
  }

  protected fun rowOf(vararg views: View) = LinearLayout(this).apply {
    orientation = LinearLayout.HORIZONTAL
    for ((i, v) in views.withIndex()) {
      addView(v, LinearLayout.LayoutParams(0, WRAP, 1f).apply {
        if (i > 0) leftMargin = dp(6)
        if (i < views.size - 1) rightMargin = dp(6)
      })
    }
  }

  protected fun field(label: String, key: String, hintText: String): LinearLayout {
    val w = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    w.addView(tv(label, 12f, cMuted).apply { setPadding(0, 0, 0, dp(6)) })
    val et = EditText(this).apply {
      setTextColor(cText)
      setHintTextColor(cMuted)
      hint = hintText
      textSize = 16f
      inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
      isSingleLine = true
      setPadding(dp(12), dp(12), dp(12), dp(12))
      background = rounded(cBg, 10, cStroke)
      val v = prefs.getFloat(key, -1f)
      if (v >= 0) setText(fmt(v))
      addTextChangedListener(object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun afterTextChanged(s: Editable?) {
          val x = s?.toString()?.toFloatOrNull()
          val ed = prefs.edit()
          if (x == null) ed.remove(key) else ed.putFloat(key, x)
          ed.apply()
        }
      })
    }
    w.addView(et)
    return w
  }

  protected fun switchRow(parent: LinearLayout, title: String, sub: String, key: String, def: Boolean): Switch {
    val sw = Switch(this).apply {
      isChecked = prefs.getBoolean(key, def)
      setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean(key, v).apply() }
    }
    val left = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL
      addView(tv(title, 16f, cText, true))
      addView(tv(sub, 12f, cMuted))
    }
    val r = LinearLayout(this).apply {
      gravity = Gravity.CENTER_VERTICAL
      setPadding(0, dp(6), 0, dp(6))
      addView(left, LinearLayout.LayoutParams(0, WRAP, 1f))
      addView(sw)
    }
    parent.addView(r)
    return sw
  }
}
