# Ride Helper
Build: push to GitHub -> Actions tab -> "Build APK" -> download artifact `app-debug`.
